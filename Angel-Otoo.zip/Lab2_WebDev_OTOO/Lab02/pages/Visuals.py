# This creates the page for displaying data visualizations.

import streamlit as st
import json
import pandas as pd
import matplotlib.pyplot as plt
# PAGE CONFIGURATION
st.set_page_config(
    page_title="Visuals",
    page_icon="📈",
)

# PAGE TITLE
st.title("Bedwars Statistics Dashboard")

st.image("Images/stats.png", width=500, caption="My Minecraft Character Stats")

st.write("""
This dashboard displays my Bedwars statistics
for several game modes.
""")
# PART 1: GRAPHS FROM data.json
# --- YOUR CODE GOES HERE ---
with open("data.json", "r") as file:
    data = json.load(file)

df = pd.DataFrame(data["data_points"])
st.header("Static Visualization")

colors = [
    "#00BFFF",  # Solo
    "#32CD32",  # Doubles
    "#FFD700",  # 3v3v3v3
    "#FF4500"   # 4v4v4v4
]

fig, ax = plt.subplots()
ax.bar(df["name"], df["Wins"],
       color=colors)
ax.set_title("Hypixel Wins")
ax.set_xlabel("Game Mode")
ax.set_ylabel("Wins")

st.pyplot(fig)

if "selected_stat" not in st.session_state:
    st.session_state.selected_stat = "Wins"

selected = st.selectbox(
    "Choose a stat",
    ["Wins", "Kills", "Final Kills", "Losses", "Deaths", "Final Deaths"]
)

st.session_state.selected_stat = selected
st.header("Dynamic Visualization")
fig, ax = plt.subplots()



ax.bar(
    df["name"],
    df[st.session_state.selected_stat],
    color=colors
)

ax.set_title(f"{st.session_state.selected_stat} by Game Mode")
ax.set_xlabel("Game Mode")
ax.set_ylabel(st.session_state.selected_stat)

st.pyplot(fig)

# PART 2: GRAPHS FROM data.csv
# --- YOUR CODE GOES HERE ---
